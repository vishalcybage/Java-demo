package com.cybage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcWorkshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcWorkshopApplication.class, args);
	}

}
