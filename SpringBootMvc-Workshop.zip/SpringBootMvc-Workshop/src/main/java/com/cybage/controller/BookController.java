package com.cybage.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cybage.pojos.Book;
import com.cybage.service.BookService;

@Controller
public class BookController {
	@Autowired
	BookService bookService;

	@GetMapping("/getAllBook")
	public ModelAndView getAllBooks() {
		List<Book> bookList = bookService.getAllBooks();
		return new ModelAndView("book", "books", bookList);
	}

	@GetMapping("/add")
	public String addBook(Model model) {
		model.addAttribute("book", new Book());
		return "addBook";
	}

	@PostMapping("/add")
	public ModelAndView addBook(@Valid @ModelAttribute("book") Book book, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return new ModelAndView("addBook", "books", book);
		}

		bookService.addBook(book);
		List<Book> bookList = bookService.getAllBooks();
		return new ModelAndView("book", "books", bookList);
	}

	@GetMapping("/delete/{id}")
	public ModelAndView deleteBook(@PathVariable int id) {

		bookService.deleteBookById(id);

		List<Book> bookList = bookService.getAllBooks();
		return new ModelAndView("book", "books", bookList);
	}

}
