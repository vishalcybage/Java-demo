package com.cybage.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.cybage.pojos.Admin;

@Service
public class AdminService {
	private List<Admin> adminList = null;

	public AdminService() {
		adminList = new ArrayList<Admin>();
		this.adminList.add(new Admin(1, "admin1", "admin1"));
		this.adminList.add(new Admin(2, "admin2", "admin2"));

	}

	public boolean verifyAdmin(Admin retrievedAdmin) {
		String retrievedName = retrievedAdmin.getName();
		String retrievedPassword = retrievedAdmin.getPassword();
		for (Admin a : adminList) {
			if (retrievedName.equals(a.getName()) && retrievedPassword.equals(a.getPassword())) {
				System.out.println("Valid USER: " + retrievedAdmin.toString());
				return true;
			}
		}
		return false;

	}

}
