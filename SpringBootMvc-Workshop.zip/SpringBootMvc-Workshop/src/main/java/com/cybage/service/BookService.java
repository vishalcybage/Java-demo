package com.cybage.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.cybage.pojos.Book;

@Service
public class BookService {
	private List<Book> bookList = null;

	public BookService() {		
		bookList = new ArrayList<Book>();
		this.bookList.add(new Book(1, "Wings of fire", "Dr.APJ Adbul Kalam"));
		this.bookList.add(new Book(2, "Man hai Vishwas", "Vishwas Nagare Patil"));
		this.bookList.add(new Book(3, "Two States", "Chetan Bhagat"));
	}

	public List<Book> getAllBooks() {

		return this.bookList;
	}

	public void addBook( Book book) {
		this.bookList.add(book);
	}

	public Book getBookByName(String name) {
		Book book= null;
		for (Book b : this.bookList) {
			if (b.getName()== name) {
				book = b;
				break;
			}
		}
		return book;

	}
	public Book getBookByAuthor(String author) {
		Book book= null;
		for (Book b : this.bookList) {
			if (b.getAuthor()== author) {
				book = b;
				break;
			}
		}
		return book;

	}
	public void deleteBookById(int id) {
		Book book= null;
		for (Book b : this.bookList) {
			if (b.getId()== id) {
				book = b;
				break;
			}
		}
		bookList.remove(book);
	}

}
