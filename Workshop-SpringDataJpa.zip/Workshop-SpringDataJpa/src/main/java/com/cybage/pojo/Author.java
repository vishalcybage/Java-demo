package com.cybage.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "authors")
public class Author {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	@NotEmpty(message = "Enter Name")
	private String name;
	@Column
	@NotEmpty(message = "Enter Email")
	private String email;
	@Column
	@NotEmpty(message = "Enter Contact No")
	private String contactNo;
	@OneToMany(mappedBy = "author")
	private List<Book> books;

	public Author(int id, @NotEmpty(message = "Enter Name") String name,
			@NotEmpty(message = "Enter Email") String email, @NotEmpty(message = "Enter Contact No") String contactNo,
			List<Book> books) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.books = books;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", email=" + email + ", contactNo=" + contactNo + ", books="
				+ books + "]";
	}

}
