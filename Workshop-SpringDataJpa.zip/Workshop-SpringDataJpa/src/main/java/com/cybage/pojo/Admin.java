package com.cybage.pojo;

import javax.validation.constraints.NotEmpty;

public class Admin {
	@NotEmpty(message = "Enter AdminName")
	private String AdminName;
	@NotEmpty(message = "Enter password")
	private String password;

	public Admin() {
	}

	public Admin(String AdminName, String password) {
		super();
		this.AdminName = AdminName;
		this.password = password;
	}

	public String getAdminName() {
		return AdminName;
	}

	public void setAdminName(String AdminName) {
		this.AdminName = AdminName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [AdminName=" + AdminName + ", password=" + password + "]";
	}

}
