package com.cybage.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cybage.pojo.Book;
import com.cybage.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;

	public BookService() {

	}

	public List<Book> getAllBooks() {
		return bookRepository.findAll();

	}

	public Book getBookById(int bookId) {
		return bookRepository.getById(bookId);
	}

	public void addBook(Book book) {
		bookRepository.save(book);
	}

	public void editBookDetails(Book book) {
		Book editbook = bookRepository.getById(book.getBookId());
		editbook.setTitle(book.getTitle());
		editbook.setPrice(book.getPrice());
		bookRepository.save(editbook);
	}

	public void deleteBook(int id) {
		bookRepository.deleteById(id);
	}

	public List<Book> getByName(String name) {
		return bookRepository.getByName(name);
	}

	public List<Book> getByAuthor(String authorName) {
		return bookRepository.getByAuthor(authorName);
	}

	public List<Book> getByPrice(double price) {
		return bookRepository.getByPrice(price);
	}

	public void deleteBookById(int id) {
		bookRepository.deleteById(id);
	}

}
