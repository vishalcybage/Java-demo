package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.pojo.Author;
import com.cybage.repository.AuthorRepository;

@Service
public class AuhorService {
	@Autowired
	AuthorRepository authorRepository;

	public AuhorService() {

	}

	public List<Author> getAllBooks() {
		return authorRepository.findAll();

	}

	public void addBook(Author author) {
		authorRepository.save(author);
	}

	public void editBookDetails(Author author) {
		Author editAuthor = authorRepository.getById(author.getId());
		editAuthor.setName(author.getName());
		editAuthor.setEmail(author.getEmail());
		editAuthor.setContactNo(author.getContactNo());
		authorRepository.save(author);
	}

	public void deleteAuthor(int id) {
		authorRepository.deleteById(id);
	}

	public List<Author> getByName(String name) {
		return authorRepository.getByName(name);
	}

	public List<Author> getByAuthorEmail(String email) {
		return authorRepository.getByEmail(email);
	}

	public void deleteAuthorById(int id) {
		authorRepository.deleteById(id);
	}

}
