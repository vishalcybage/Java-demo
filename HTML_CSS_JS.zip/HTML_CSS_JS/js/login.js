

$(document).ready(function () {
    $('#login-form').submit(function (e) {
        e.preventDefault();
        var users = [];
        $.getJSON("../Json Server/db.json", function (data) {
            console.log(data.users);
            users = data.users;
            const username = $('#login_email').val();
            const upassword = $('#pwd').val();
    
            users.forEach((u) => {
                console.log(u.email);
                if (u.email == username || u.mobileNumber == username) {
                    if (u.password == upassword) {
                        sessionStorage.setItem("UserDetails", JSON.stringify(u));
                        window.location.href = "../html/home.html";
                        alert('Successful');
                    } else {
                        alert('Wrong passaword');
                        $('#err-user-details-email').html("");
                        $('#err-user-details-password').html("Incorrect Password");
                    }
                } else {
                    $('#err-user-details-email').html("Incorrect Email");
                    alert('wrong email');
                }
            })
            console.log('in login');
        });
    
    })
});









