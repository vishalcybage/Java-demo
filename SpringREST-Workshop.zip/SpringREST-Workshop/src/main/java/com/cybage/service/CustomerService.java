package com.cybage.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Customer;
import com.cybage.dao.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepository;

	public CustomerService() {

	}

	public List<Customer> getAllCustomer() {
		return customerRepository.findAll();
	}

	public void addCustomer(Customer customer) {
		customerRepository.save(customer);
	}

	public Optional<Customer> getCustomerById(int id) {
		return customerRepository.findById(id);
	}

	public void deleteById(int id) {
		customerRepository.deleteById(id);
	}

	public Customer updateCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	public Customer findByEmail(String email) {
		return customerRepository.findByEmail(email);
	}

	public List<Customer> findByName(String name) {
		return customerRepository.findByName(name);
	}

	public List<Customer> findByAddress(String address) {
		return customerRepository.findByAddress(address);
	}

}
